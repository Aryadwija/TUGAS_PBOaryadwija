package aryadwija;

public class Luas_Segitiga {
    public static void main(String[] args) {
        int a = 15;
        int t = 25;
        double Luas = 0.5 * a * t;
        
        System.out.println ("alas = " + (a));
        System.out.println ("tinggi = " + (t));
        System.out.println ("Luas Segitiga = " + (Luas));
    }
}
