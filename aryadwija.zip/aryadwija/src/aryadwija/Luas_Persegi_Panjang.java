package aryadwija;

public class Luas_Persegi_Panjang {
    
    public static void main(String[] args) {
        int p = 15;
        int l = 20;
        int t = 10;
        double Luas = p * l * t;
        
        System.out.println ("panjang = " + (p));
        System.out.println ("lebar = " + (l));
        System.out.println ("tinggi = " + (t));
        System.out.println ("Luas Persegi = " + (Luas));
    }
    
}
